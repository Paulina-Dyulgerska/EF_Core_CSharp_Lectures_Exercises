﻿namespace PetStore.ServiceModels.Products
{
   public class ProductOutputModel
    {
        public string Name { get; set; }

        public int  OfficialId { get; set; }

        public string ProductType { get; set; }

        public decimal Price { get; set; }
    }
}
