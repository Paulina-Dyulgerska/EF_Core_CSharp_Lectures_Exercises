﻿namespace P03_SalesDatabase.Data
{
    internal static class Configurator
    {
        internal static string connectionString =
            @"Server=.\SQLEXPRESS;Database=Sales;Integrated Security=true;";
    }
}
