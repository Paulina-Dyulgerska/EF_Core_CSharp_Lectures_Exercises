﻿using System;

namespace PetStore.Common
{
    public static class DbConfiguration
    {
        public static string ConnectionString = @"Server=.\SQLEXPRESS;DataBase=PetShop;Integrated Security=true;";
    }
}
